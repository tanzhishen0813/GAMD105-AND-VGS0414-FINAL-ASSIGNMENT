const navBtns = document.querySelectorAll(".nav-btn");
const pages = document.querySelectorAll(".page");
const favCountEl = document.getElementById("fav-count");
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modalBody");
const closeModalBtn = document.getElementById("closeModal");

let favorites = [];


navBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const view = btn.dataset.view;
    pages.forEach(page => page.classList.add("hidden"));
    if(view) document.getElementById(view).classList.remove("hidden");
    if(view === "favorites") renderFavorites();
  });
});

function copyCardsToSearch() {
  const popularList = document.getElementById("popularList");
  const resultList = document.getElementById("resultList");
  resultList.innerHTML = popularList.innerHTML;
}
document.addEventListener("DOMContentLoaded", copyCardsToSearch);


function searchCards(inputId, cardContainerId){
  const input = document.getElementById(inputId);
  const container = document.getElementById(cardContainerId);
  const filter = input.value.toLowerCase();
  const cards = container.querySelectorAll(".col-md-4");
  cards.forEach(card => {
    const title = card.querySelector(".card-title").textContent.toLowerCase();
    card.style.display = (!filter || title.includes(filter)) ? "" : "none";
  });
}
document.getElementById("searchBtnTop").addEventListener("click", () => searchCards("searchInputTop","popularList"));
document.getElementById("searchBtn").addEventListener("click", () => {
  searchCards("searchInput","resultList");
  updateRecipesAndRestaurants(document.getElementById("searchInput").value.trim());
});
document.getElementById("searchInputTop").addEventListener("keypress", e => { if(e.key==="Enter") searchCards("searchInputTop","popularList"); });
document.getElementById("searchInput").addEventListener("keypress", e => { 
  if(e.key==="Enter"){ 
    searchCards("searchInput","resultList");
    updateRecipesAndRestaurants(document.getElementById("searchInput").value.trim());
  }
});


document.addEventListener("click", e => {
  if(e.target.classList.contains("fav-btn")){
    const card = e.target.closest(".col-md-4");
    const title = card.querySelector(".card-title").textContent;
    if(!favorites.includes(title)) favorites.push(title);
    favCountEl.textContent = favorites.length;
    e.target.textContent = "❤️ Favorited";
    renderFavorites();
  }
});


document.addEventListener("click", e => {
  if(e.target.matches(".btn[data-id]")) {
    const foodName = e.target.dataset.id;
    showModal(foodName);
  }
});


closeModalBtn.addEventListener("click", () => {
  modal.classList.add("hidden");
});
modal.addEventListener("click", e => {
  if(e.target === modal) modal.classList.add("hidden");
});

function renderFavorites(){
  const favList = document.getElementById("favoritesList");
  const allCards = document.querySelectorAll("#popularList .col-md-4");
  favList.innerHTML = "";
  allCards.forEach(card => {
    const title = card.querySelector(".card-title").textContent;
    if(favorites.includes(title)){
      favList.appendChild(card.cloneNode(true));
    }
  });
}


const recipesData = {
  "chicken rice": ["Hainanese Chicken Rice", "Soy Sauce Chicken Rice", "Garlic Chicken Rice"],
  "nasi lemak": ["Nasi Lemak with Fried Chicken", "Vegetarian Nasi Lemak"],
  "laksa": ["Penang Laksa", "Curry Laksa"],
  "roti canai": ["Roti Canai with Dhal", "Roti Canai with Curry"],
  "hainanese chicken chop": ["Classic Chicken Chop", "Spicy Chicken Chop"],
  "mee goreng mamak": ["Mamak Mee Goreng", "Spicy Fried Noodles"],
  "cendol": ["Traditional Cendol", "Cendol with Red Beans"]
};


const restaurantsData = {
  "chicken rice": [
    {name:"Ah Wong Chicken Rice", address:"No.12, Jalan Bukit Bintang, Kuala Lumpur"},
    {name:"Restoran Hainan", address:"45, Jalan Alor, Kuala Lumpur"},
    {name:"Chicken Rice King", address:"78, Jalan Imbi, Kuala Lumpur"}
  ],
  "nasi lemak": [
    {name:"Nasi Lemak Kukus", address:"22, Jalan Pudu, Kuala Lumpur"},
    {name:"Village Nasi Lemak", address:"5, Jalan Sultan Ismail, Kuala Lumpur"},
    {name:"Sedap Corner", address:"33, Jalan Raja Chulan, Kuala Lumpur"}
  ],
  "laksa": [
    {name:"Penang Laksa House", address:"10, Jalan Chow Kit, Kuala Lumpur"},
    {name:"Laksa Street Stall", address:"7, Jalan Alor, Kuala Lumpur"}
  ],
  "roti canai": [
    {name:"Mamak Roti Canai", address:"3, Jalan Imbi, Kuala Lumpur"},
    {name:"Roti Canai Corner", address:"15, Jalan Bukit Bintang, Kuala Lumpur"}
  ],
  "hainanese chicken chop": [
    {name:"Old Town Chicken Chop", address:"21, Jalan Pahang, Kuala Lumpur"},
    {name:"Cafe Hainanese", address:"8, Jalan Tuanku Abdul Rahman, Kuala Lumpur"}
  ],
  "mee goreng mamak": [
    {name:"Mamak Stall 99", address:"11, Jalan Alor, Kuala Lumpur"},
    {name:"Mee Goreng Express", address:"6, Jalan Sultan Ismail, Kuala Lumpur"}
  ],
  "cendol": [
    {name:"Cendol Station", address:"2, Jalan Bukit Bintang, Kuala Lumpur"},
    {name:"Sweet Treats Cafe", address:"18, Jalan Pudu, Kuala Lumpur"}
  ]
};

function updateRecipesAndRestaurants(foodName){
  const recipes = recipesData[foodName.toLowerCase()] || [];
  const restaurants = restaurantsData[foodName.toLowerCase()] || [];
  const recipeList = document.getElementById("recipeList");
  const restaurantList = document.getElementById("restaurantList");
  recipeList.innerHTML = recipes.length ? recipes.map(r=>`<li>${r}</li>`).join("") : "<li>No recipes found.</li>";
  restaurantList.innerHTML = restaurants.length ? restaurants.map(r=>`<li>${r.name} - ${r.address}</li>`).join("") : "<li>No nearby restaurants found.</li>";
}

function showModal(foodName){
  const recipes = recipesData[foodName.toLowerCase()] || [];
  const restaurants = restaurantsData[foodName.toLowerCase()] || [];
  modalBody.innerHTML = `
    <h2>${foodName}</h2>
    <h3>Recipe Details</h3>
    <ul>${recipes.length ? recipes.map(r=>`<li>${r}</li>`).join("") : "<li>No recipes found.</li>"}</ul>
    <h3>Nearby Restaurants</h3>
    <ul>${restaurants.length ? restaurants.map(r=>`<li>${r.name} - ${r.address}</li>`).join("") : "<li>No nearby restaurants found.</li>"}</ul>
  `;
  modal.classList.remove("hidden");
}

document.getElementById("nearbyBtn").addEventListener("click", showNearbyRestaurants);
document.getElementById("nearbyInput").addEventListener("keypress", e => {
  if(e.key === "Enter") showNearbyRestaurants();
});

function showNearbyRestaurants() {
  const input = document.getElementById("nearbyInput");
  const filter = input.value.trim().toLowerCase();
  const nearbyList = document.getElementById("nearbyList");
  nearbyList.innerHTML = "";

  if(!filter){
    nearbyList.innerHTML = "<p>Please enter a food name to search nearby restaurants.</p>";
    return;
  }

  const restaurants = restaurantsData[filter] || [];
  if(restaurants.length === 0){
    nearbyList.innerHTML = "<p>No nearby restaurants found for this food.</p>";
    return;
  }

  restaurants.forEach(r => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="card-body">
        <h5 class="card-title">${r.name}</h5>
        <p class="card-text text-muted">${r.address}</p>
      </div>
    `;
    nearbyList.appendChild(card);
  });
}

recipesData["chicken rice"] = ["Hainanese Chicken Rice", "Soy Sauce Chicken Rice", "Garlic Chicken Rice"];
recipesData["nasi lemak"] = ["Nasi Lemak with Fried Chicken", "Vegetarian Nasi Lemak"];
recipesData["laksa"] = ["Penang Laksa", "Curry Laksa"];
recipesData["roti canai"] = ["Roti Canai with Dhal", "Roti Canai with Curry"];
recipesData["cendol"] = ["Traditional Cendol", "Cendol with Red Beans"];

restaurantsData["chicken rice"] = [
  {name:"Ah Wong Chicken Rice", address:"No.12, Jalan Bukit Bintang, Kuala Lumpur"},
  {name:"Restoran Hainan", address:"45, Jalan Alor, Kuala Lumpur"},
  {name:"Chicken Rice King", address:"78, Jalan Imbi, Kuala Lumpur"}
];
restaurantsData["nasi lemak"] = [
  {name:"Nasi Lemak Kukus", address:"22, Jalan Pudu, Kuala Lumpur"},
  {name:"Village Nasi Lemak", address:"5, Jalan Sultan Ismail, Kuala Lumpur"},
  {name:"Sedap Corner", address:"33, Jalan Raja Chulan, Kuala Lumpur"}
];
restaurantsData["laksa"] = [
  {name:"Penang Laksa House", address:"10, Jalan Chow Kit, Kuala Lumpur"},
  {name:"Laksa Street Stall", address:"7, Jalan Alor, Kuala Lumpur"}
];
restaurantsData["roti canai"] = [
  {name:"Mamak Roti Canai", address:"3, Jalan Imbi, Kuala Lumpur"},
  {name:"Roti Canai Corner", address:"15, Jalan Bukit Bintang, Kuala Lumpur"}
];
restaurantsData["cendol"] = [
  {name:"Cendol Station", address:"2, Jalan Bukit Bintang, Kuala Lumpur"},
  {name:"Sweet Treats Cafe", address:"18, Jalan Pudu, Kuala Lumpur"}
];